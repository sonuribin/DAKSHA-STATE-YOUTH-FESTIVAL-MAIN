<?php
include "conn.php";
?>

<head><title>REGISTRATION</title>
<link rel="stylesheet" href="style2.css">
<style>
body
{
background-image: url("dancer-2349565.png");
text-shadow: hsla(hue, saturation, lightness, alpha);	
}
form
{
text-shadow: hsla(hue, saturation, lightness, alpha);
background-color:#1bcca0;
letter-spacing: 0pt;
width:600px;
height: 700px;
border:10px ;
padding:40 px;
margin-top:80px;
margin-left: 900px;
text-align: center;
}



span{
font-size: 16px;
margin-left: 10px;
font family: sans-serif;
}

.input-box
{
width: 88%;
height: 40px;

	
	
	border-radius: 00px;
	padding: 0 10px;


}
.input-box1
{
width: 78%;
height: 40px;
margin-left: -50px;

	
	
	border-radius: 00px;
	padding: 0 10px;


}

.button
{
	background-color: #ff6666;
 height: 32px;
  color: white;
  padding: 2spx 32px;
  
  text-align: center;
  
  display: inline-block;
  font-size: 19px;
	border-radius: 12px;
.style1 {font-size: 10px}
</style>
</head>
<br>
 <body>
 	<a href="home1.php">HOME</a>
 <form role="form" method="POST" action="codes/reg_action.php">
  <br>
  <p align="center"><strong><h1 style="color:white;">REGISTRATION</strong></p></h1>
    <div>
		<div class="input-box">
						<span class="lnr lnr-user"></span>
						<input name="fname" type="text" class="input-box" id="nme" title="First Name" onchange="Validate();" placeholder="Enter The First Name" required>
					
	</div>
					<span id="msg1" style="color:black;"></span>
<script>		
function Validate() 
{
    var val = document.getElementById('nme').value;

    if (!val.match(/^[A-Za-z]{3,}$/)) 
    {
        document.getElementById('msg1').innerHTML="Only alphabets are allowed!!";
		            document.getElementById('nme').value = "";
        return false;
    }
document.getElementById('msg1').innerHTML=" ";
    return true;
}
</script>
<br>
					<div class="input-box">
					<span class="lnr lnr-user"></span>
					<input name="lname" type="text" class="input-box" id="lnme" title="Last Name" onchange="Validate1();" placeholder="Enter The Last Name" required>
					</div>
					<span id="msg2" style="color:black;"></span>
<script>		
function Validate1() 
{
    var val = document.getElementById('lnme').value;

    if (!val.match(/^[A-Za-z/./ /]{0,}$/)) 
    {
        document.getElementById('msg2').innerHTML="Only alphabets are allowed!!";
		            document.getElementById('lnme').value = "";
        return false;
    }
document.getElementById('msg2').innerHTML=" ";
    return true;
}
</script>
	<br>				
					<div class="input-box">
					<span class="lnr lnr-calendar-full"></span>
					<input type="date" name="dob" id="dob" class="input-box" min="1999-01-01" max="2005-01-01" title="Date of birth" placeholder="Enter the Date of Birth"required >		</div>
					<span id="demo" style="color:black;"></span>
					<script>
						function myFunction() 
					{
						var x = document.getElementById("dob").max;
						document.getElementById("demo").innerHTML = "Invalid Date!!";
					}
					
</script>


<br>
					<div >
					  <div  class="input-box" style="padding-top: 7px;padding-bottom: 7px;>
					<span class="lnr lnr-users"></span>
					<input type="radio"  name="gender" value="male"required> Male
					<input type="radio" name="gender" value="female"required> Female
					<input type="radio" name="gender" value="others"required> Others
					</div>
					<?php
					$qu="select * from tbl_district";
					$s=mysqli_query($conn,$qu);

					 ?>
				
	  </div>
	  <select class="input-box1"  name="district" id="type" required>
	  <option value=""disabled selected>Enter The District</option>
	  <?php
while($d=mysqli_fetch_array($s))
{
	?>
	  <option value="<?php echo $d['di_id']; ?>"><?php echo $d['district']; ?></option>
	  <?php } ?>
			

			</select>
			<br><br><div class="input-box">
			<span class="lnr lnr-phone-handset"></span>
			<input name="phone" type="text" class="input-box" id="phn" title="Phone Number" onchange="Validat();" placeholder="Enter The Phone Number" required>
			</div>
			<span id="msg4" style="color:black;"></span>
			
<script>
function Validat() 
{
    var val = document.getElementById('phn').value;

    if (!val.match(/^[7-9][0-9]{1,9}$/)) 
    {
        document.getElementById('msg4').innerHTML="Only Numbers are allowed and must contain 10 number";
	
		
		            document.getElementById('phone').value = "";
        return false;
    }
document.getElementById('msg4').innerHTML=" ";
    return true;
}

</script>
		<br>			<div class="input-box">
						<span class="lnr lnr-envelope"></span>
						<input type="email" name="email" id="email" title="E-Mail" class="input-box" placeholder="Enter The E-Mail [Eg: xyz@gmail.com]" required onchange="return Validata();">
					</div>
					<span id="msg5" style="color:black;"></span>
<script>		
function Validata() 
{
    var val = document.getElementById('email').value;

    if (!val.match(/([A-z0-9_\-\.]){1,}\@([A-z0-9_\-\.]){1,}\.([A-Za-z]){2,4}$/))
    {
        document.getElementById('msg5').innerHTML="Enter a Valid Email";
		
		     document.getElementById('email').value = "";
        return false;
    }
document.getElementById('msg5').innerHTML=" ";
    return true;
}

		</script>
		<br>
					<div class="input-box">
						<span class="lnr lnr-lock"></span>
						<input name="password" type="password" class="input-box" id="pwd" title="Password" onchange="return Validp();" placeholder="Enter the Password" required>
					</div>
					<span id="msg6" style="color:black;"></span>
<script>		
function Validp() 
{
    var val = document.getElementById('pwd').value;

    if (!val.match(/^[A-Za-z0-9!-*]{6,15}$/)) 
    {
        document.getElementById('msg6').innerHTML="Password should contain atleast 6 characters";
		
		     document.getElementById('pwd').value = "";
        return false;
    }
document.getElementById('msg6').innerHTML=" ";
    return true;
}

</script>
					<br><div class="input-box">
						<span class="lnr lnr-lock"></span>
						<input name="confirm" type="password" class="input-box" id="confirm" title="Confirm Password" onchange="return check();" placeholder="Enter the Confirm Password" required>
					</div>
					<span id="msg7" style="color:black;"></span>
					<script>
	function check()
{
var pas1=document.getElementById("pwd");
							  var pas2=document.getElementById("confirm");
							
							  if(pas1.value=="")
	{
		document.getElementById('msg7').innerHTML="Password can't be null!!";
		pas1.focus();
		return false;
	}
	if(pas2.value=="")
	{
		document.getElementById('msg7').innerHTML="Please confirm password!!";
		pass2.focus();
		return false;
	}
	if(pas1.value!=pas2.value)
	{
		document.getElementById('msg7').innerHTML="Passwords does not match!!";
		pas1.focus();
		return false;
	}
     document.getElementById('msg7').innerHTML=" "; 
	return true;
}
	</script>
					
					
			
			
			</div>
			<br>
            <div class="button">
					
<button type="submit" class="button" name="submit" value="Register">
					<div align="center"><span class="style1"></span>Register
				    </div>
					</button>
		  </div>
					<br><br><center><a href="plogin.php">Login Here...</a>
	</div>
  </form>
  </body>
</center>

<?php
;
?>