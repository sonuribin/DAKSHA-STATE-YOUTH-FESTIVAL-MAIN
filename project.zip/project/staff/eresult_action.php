<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klp";
$conn = new mysqli($servername,$username, $password,$dbname);
    
if(isset($_POST['submit'])){
        $sql= "INSERT INTO tbl_point (event,uid,mark) VALUES";
       
        $rows=[];
    for($i=0;$i<count($_POST["uid"]);$i++){
      $rows[]="('{$_POST['event']}','{$_POST['uid'][$i]}','{$_POST['mark'][$i]}')";
    }
    $sql.=implode(",",$rows);
    if($conn->query($sql)){
      echo "Mark Added Successfully";
       header('Location:eresult.php');
    }else{
      echo "Adding Failed!!!";
    }
     
   


    


}

?>