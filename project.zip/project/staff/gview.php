<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <link rel="stylesheet" href="style2.css">
<style>
<body>

</style>
</head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin</title>
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">STAFF</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;">  
        </nav>   
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                <li class="text-center">
                    <img src="assets/img/find_user.png" class="user-image img-responsive"/>
                    </li>
                    <li>
                       
                      <li>
                        <a  href="schedule.php"><i class="fa fa-dashboard fa-3x"></i> SCHEDULE PROGRAM</a>
                    </li>
                        <li>
                        <a  href="eresult.php"><i class="fa fa-desktop fa-3x"></i>ENTER RESULTS</a>
                    </li>
                      <li>
                        <a  href="scheview2.php"><i class="material-icons"style="font-size:30px;color:white;">visibility</i>UPCOMING EVENTS</a>
                    </li>
                     <li>
                        <a  href="schehist.php"><i class="material-icons"style="font-size:30px;color:white;">visibility</i>SCHEDULE HISTORY</a>
                    </li>
                    <li>
                        <a  href="eventview1.php"><i class="material-icons"style="font-size:30px;color:white;">visibility</i>VIEW EVENT REGISTRATIONS</a>
                    </li>
                    <li>
                        <a  href="gview.php"><i class="material-icons"style="font-size:30px;color:white;">visibility</i>GROUP EVENT REGISTRATIONS</a>
                    </li>
                    <li>
                        <a  href="resultview.php"><i class="material-icons"style="font-size:30px;color:white;">visibility</i>VIEW RESULT</a>
                    </li>
                    <li>
                        <a  href="point.php"><i class="material-icons"style="font-size:30px;color:white;">visibility</i>VIEW MARKS</a>
                    </li>
            </div> 
             </nav>  
        
        <hr>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     
                     <body>
                        <body>
    <a href="staffentr.php">Back to Staff</a>

</form>
</div>
  </body>
</head>
</html>
<h1 style="color:red" align="center">GROUP EVENT REGISTRATIONS</h1>

<?php
$errors=array();
$db=mysqli_connect('localhost','root','','klp');
 if($db){
        echo "";
    }else{
        echo 'Error'.$db->error;
    }
$query=("SELECT * FROM tbl_group");
$results = mysqli_query($db, $query);
if(!$results)
{
die("selection error".mysql_connect_error());
}
else
{
echo " ";
}
?>

                        <div class="">
                        <center><table   width="100%"   border="0" class="table table-bordered">
                            <tr><table border=5 bordercolor=black>
                           <thead style="color:red" align="center">
                            <th height="50px" width="20%">SL NO.</th>
                            <th height="50px" width="40%">EVENT</th>
                            <th height="50px" width="40%">DISTRICT</th>
                            </thead>

   <?php 
                                   $count=0; 
                                    while($row=mysqli_fetch_assoc($results))
                    
                                    {
                                        $count++;
                    ?>
<tbody style="color:black;" align="center">
<tr><td height="50px"><?php echo $count ?></td>
    <td height="50px"><?php echo $row['list'];?></td>
    <td height="50px"><?php echo $row['district'];?></td>
    </td>

</tr></tbody>
<?php
}
?>
<?php
echo"
</table>";

?>
        </div></center>
    </ul>
</body>
</html>