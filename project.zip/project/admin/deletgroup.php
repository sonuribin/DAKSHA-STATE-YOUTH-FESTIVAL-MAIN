<?php
	$g_id=$_GET['g_id'];
	include('conn.php');
	mysqli_query($conn,"delete from `tbl_group` where g_id='$g_id'");
	header('location:groupview.php');
?>