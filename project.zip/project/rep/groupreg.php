
<?php
include 'conn.php';
session_start();
$bb=$_SESSION['rep'];

?>
<head>
    <link rel="stylesheet" href="style2.css">
<style>
body
{
background-image: url("dancer-2349565.png");
text-shadow: hsla(hue, saturation, lightness, alpha);   
}
form
{
text-shadow: hsla(hue, saturation, lightness, alpha);
background-color:#1bcca0;
letter-spacing: 0pt;
width:400px;
height: 300px;
border:30px ;
padding:40 px;
margin-top:70px;
margin-left: 550px;
text-align: center;
}
.ss{
  padding: 15px;
  font-size: 16px;
  color: black;
  background:#1aa3ff;
  border: none;
  border-radius: 4px;
}
.input-box1
{
width: 70%;
height: 60px;

    
    
    border-radius: 00px;
    padding: 0 10px;

</style>
</head>
<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Free Bootstrap Admin Template : Binary Admin</title>
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">DISTRICT REP</a> 
            </div>
 
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                <li class="text-center">
                    <img src="assets/img/find_user.png" class="user-image img-responsive"/>
                    </li>
                
                    
                   <li>
                        <a  href="stview.php"><i class="material-icons"style="font-size:30px;color:red;">edit</i> VIEW/REMOVE PARTICIPANTS</a>
                    </li>
                    <li>
                        <a  href="groupreg.php"><i class="material-icons"style="font-size:30px;color:red;">add</i>GROUP EVENT REGISTRATIONS</a>
                    </li>
                      <li>
                        <a  href="scheview1.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i>UPCOMING EVENTS</a>
                    </li>
                    <li>
                        <a  href="schehist.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i>SCHEDULE HISTORY</a>
                    </li>
                    <li>
                        <a  href="eventview2.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i>VIEW/REMOVE EVENT REGISTRATIONS</a>
                    </li>
                    <li>
                    <a  href="rresultview.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i>VIEW RESULT</a>
                    </li>
               
            </div>
             </nav>  
        
        <hr>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     
                     
    <body>
        <a href="repenter.php">Back To Rep</a>
        <h1 align="center" style="color:red"> EVENT REGISTRATION</h1>

        <div class="a"><br>
                <h1 align="center">GROUP ITEMS</h1>
                <form method="POST" action="group_action.php">
<P> SELECT THE GROUP ITEMS</p></P>
<?php
                    $qu="select * from tbl_prog";
                    $s=mysqli_query($conn,$qu);
                    ?>
      <select   name="list" id="type" required>
      <option value=""disabled selected>Enter The event</option>
      <?php
while($d=mysqli_fetch_array($s))
{
    ?>
      <option value="<?php echo $d['gname']; ?>"><?php echo $d['gname']; ?></option>
      <?php } ?>
        </select><br>
         
<p>DISTRICT</p>
<?php 
$w= mysqli_query($conn,"SELECT * FROM `tbl_rep` join `tbl_district` on tbl_district.di_id = tbl_rep.d_id where tbl_rep.login_id='$bb'");
while($qw = mysqli_fetch_array($w))
{
    ?>
    <input type="text" name="district" readonly="" value="<?php echo $qw['district']; ?>"></p><BR><br>
    <input type='submit'  class="btn" name='submit' value='Submit' /><br><br>
<?php
 }
?>


        
        
    </form>
    
  
    
    </div>  
    
    </ul>
</body>
</html>