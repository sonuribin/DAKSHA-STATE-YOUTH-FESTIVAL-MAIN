<?php
include "conn.php";
?>
<head><title>REGISTRATION</title>
<link rel="stylesheet" href="style2.css">
<style>
body
{
background-image: url("dancer-2349565.png");
text-shadow: hsla(hue, saturation, lightness, alpha);   
}
form
{
text-shadow: hsla(hue, saturation, lightness, alpha);
background-color:#e3dada;
letter-spacing: 0pt;
width:500px;
height: 250px;
border:10px ;
padding:40 px;
margin-top:80px;
margin-left: 400px;
text-align: center;
}



span{
font-size: 16px;
margin-left: 10px;
font family: sans-serif;
}

.input-box
{

width: 88%;
height: 30px;
float: none;
    
    
    border-radius: 00px;
    padding: 0 10px;


}
.input-box1
{

width: 72%;
height: 30px;

    
    
    border-radius: 00px;
    padding: 0 20px;
}


.button
{
    background-color: #ff1100;
 height: 32px;
  color: white;
  padding: 2spx 32px;
  position: absolute;
  left: 320px;
  bottom: 550px;
  text-align: center;
  
  display: inline-block;
  font-size: 19px;
    border-radius: 12px;
.style1 {font-size: 10px}
}


</style>
</head>
<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">admin</a> 
            </div>
 
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <img src="assets/img/find_user.png" class="user-image img-responsive"/>
					</li>
				
					
                      <li>
                        <a  href="staff_reg.php"><i class="material-icons"style="font-size:30px;color:red;">supervisor_account</i> ADD A STAFF</a>
                    </li>
                    <li>
                        <a  href="rep_reg.php"><i class="material-icons"style="font-size:30px;color:red;">person</i> ADD A REPRESENTATIVE</a>
                    </li>
                    <li>
                        <a  href="judge.php"><i class="material-icons"style="font-size:30px;color:red;">person</i> ADD A JUDGE</a>
                    </li>
						   <li  >
                        <a  href="eventview.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i> VIEW PROGRAM REGISTRATIONS</a>
                    </li>	
                      <li  >
                        <a  href="groupview.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i> VIEW GROUP EVENT REGISTRATION</a>
                    </li>
                    <li  >
                        <a  href="scheview.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i> UPCOMING EVENTS</a>
                    </li>
                    <li>
                     <a  href="histsche.php"><i class="material-icons"style="font-size:30px;color:red;">edit</i> SCHEDULE HISTORY</a>
                    </li>   				
					<li  >
                        <a  href="result2.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i> VIEW RESULT</a>
                    </li>
                    <li  >
                        <a  href="stview.php"><i class="material-icons"style="font-size:30px;color:red;">edit</i> VIEW/REMOVE STAFF</a>
                        <li  >
                             <a  href="repview.php"><i class="material-icons"style="font-size:30px;color:red;">edit</i> VIEW/REMOVE REPRESENTATIVE</a>
                    </li>
                     <li  >
                             <a  href="districtadd.php"><i class="material-icons"style="font-size:30px;color:red;">edit</i> ADD A DISTRICT</a>
                    
                     <li>
                     <a  href="eventadd.php"><i class="material-icons"style="font-size:30px;color:red;">edit</i> ADD AN EVENT</a>
                    </li>
                     <li>
                     <a  href="groupeventadd.php"><i class="material-icons"style="font-size:30px;color:red;">edit</i> ADD A GROUP EVENT</a>
                    </li>
                
               
            </div>
            
        </nav>  
        
        <hr>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     
                     <body>
                        <body>
    <a href="adminp.php">Back To Admin</a>
  <form action="eevent_action.php" method="POST" >
    <table class="table table-bordered">
      <h1>ADD AN EVENT</h1>
      <hr>


      <tr>
        <th>Enter event name:</th>
        <td><input type="text" name="event" id="event" class="form-control"/>
        </td>
      </tr>
      
     

   

      <div class="button">
                    
<button type="submit" class="button" name="submit" value="Register" >
                    <div align="center"><span class="style1"></span>Register
                    </div>
    </table>
  </form>

  <?php 

    include ("conn.php");
    $query = " select * from tbl_event";
    $result = mysqli_query($conn,$query);

?>

        
                    <div class=""><h3><center>EVENT</center></h3>
                        <table align="center" width="50%"   border="0" class="table table-bordered">
                            <tr>
                                <th width="35px"> Sl no</th>
                                <th width="200px"> EVENT </th>
                               <th width="100px"> Edit/Update</th>
                                </tr>       
                            <?php 
                                   $count=0; 
                                    while($row=mysqli_fetch_assoc($result))
                    
                                    {
                                        $count++;
                    ?>
                                        
                                    <tr>
                                        <td><?php echo $count ?></td>
                    
                                        <td><?php echo $row['event'] ?></td>
                                        
                                        
                                        
                                       <td height="50px" style="color:black;" align="center"><a href="even_update.php?id= <?php echo $row['e_id']; ?>" class="btn btn-success" style="align:center">Edit/Update</a>
                                    
                                            
                                        </a>
                                        </td>
                                        

                                    </tr>   
                             <?php
                  
                  }                 
                            
                             ?>                                                                   
                      </table>
                    </div>
                </div>
            </div>
        </div>
  
 

  
</body>
</html>





