<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klp";
$conn = new mysqli($servername,$username, $password,$dbname);

if(isset($_POST['submit'])){
$event =$_POST['event'];
$query = "SELECT * FROM tbl_event WHERE event='$event' ";
$userId = mysqli_query($conn, $query);
if(mysqli_num_rows($userId) < 1){
    
   
  $details= "INSERT into tbl_event (event)values('$event')";
  if(mysqli_query($conn, $details)) 
  {

      
        echo "<script>
        alert('Type added succesfully');
      </script>";

 
      header('location:eventadd.php');
    }

   
  }
  else{
      echo "<script>alert('event already exist');</script>";
}
}

mysqli_close($conn);
?>
  