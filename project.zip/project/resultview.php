<?php
include 'conn.php';

?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <link rel="stylesheet" href="style2.css">
<style>
body
{
background-image: url("666.jpg");
text-shadow: hsla(hue, saturation, lightness, alpha);   
}



span{
font-size: 16px;
margin-left: 10px;
font family: sans-serif;
}

.input-box
{

width: 88%;
height: 30px;
float: none;
    
    
    border-radius: 00px;
    padding: 0 10px;


}
select {
width: 400px;
height: 50px;
line-height: 50px;
-webkit-appearance: menulist-button;
-moz-appearance:none;
}


</style>
</head>
</html>
<a href="home1.php">HOME</a>
<h1 style="color:red" align="center">RESULT</h1>

 <div>
             <form method="POST" action="">
            <P>Event</P>
            <select  name="list" id="type" onchange="change();" required>
                        <option value=""disabled selected>select the program</option>
        <?php
        $i=0;
            $sel=mysqli_query($conn,"select * from  tbl_event");
             while($r=mysqli_fetch_array($sel))
            {
            ?>
           <option value="<?php echo $r['event'];?>"><?php echo $r['event'];?></option>
            <?php
        }
        ?>
        </select>  </form>
    </div><br>
        <div>
    <center>
        <table width="100%" border="0" class="table table-bordered">
            <tr>
                <table border=5 bordercolor=black>
                    <thead style="color:red">
                         <th height="50px" width="3%"></th>
                        <th height="50px" width="8%">NAME</th>
                        <th height="50px" width="8%">DISTRICT</th>
                    </div>

                            
             </thead>
        <tbody id="event">
        </tbody>
            </select>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
      <script>
                                            function change() {
                                                var country = $("#type").val();

                                                $.ajax({
                                                    type: "POST",
                                                    url: "resview.php",
                                                    data: "country=" + country,
                                                    cache: false,
                                                    success: function(response) {
                                                        //alert(response);return false;
                                                        $("#event").html(response);
                                                    }
                                                });

                                            }
                                  </script>   

    </form> 
        </a>
    </div>  
    
    </ul>   
</body>
</html>
<?php
;
?>