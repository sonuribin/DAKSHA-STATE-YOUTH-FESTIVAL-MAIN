<?php
session_start();
echo "<script>window.location.href='home1.php';</script>";
            ?>