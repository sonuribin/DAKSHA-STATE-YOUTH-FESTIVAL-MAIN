<?php
include 'conn.php';
?>
<head>
    <link rel="stylesheet" href="style2.css">
<style>
body
{
background-image: url("dancer-2349565.png");
text-shadow: hsla(hue, saturation, lightness, alpha);   
}
form
{
text-shadow: hsla(hue, saturation, lightness, alpha);
background-color:#8d91a1;
letter-spacing: 0pt;
width:600px;
height: 400px;
border-radius: 10% ;
padding:40 px;
margin-top:70px;
margin-left: 450px;
text-align: center;
}
.ss{
  padding: 15px;
  font-size: 16px;
  color: black;
  background:#1aa3ff;
  border: none;
  border-radius: 4px;
}
.input-box
{
width: 88%;
height: 30px;

    
    
    border-radius: 00px;
    padding: 0 10px;

</style>
</head>
<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin</title>
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">STAFF</a> 
            </div>
            
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                <li class="text-center">
                    <img src="assets/img/find_user.png" class="user-image img-responsive"/>
                    </li>
                    </li>
                
                    
                  <li>
                        <a  href="schedule.php"><i class="fa fa-dashboard fa-3x"></i> SCHEDULE SINGLE EVENT</a>
                    </li>
                        <li>
                        <a  href="eresult.php"><i class="fa fa-desktop fa-3x"></i>ENTER RESULTS</a>
                    </li>
                     <li>
                        <a  href="scheview2.php"><i class="material-icons"style="font-size:30px;color:white;">visibility</i>UPCOMING EVENTS</a>
                    </li>
                     <li>
                        <a  href="schehist.php"><i class="material-icons"style="font-size:30px;color:white;">visibility</i>SCHEDULE HISTORY</a>
                    </li>
                    <li>
                        <a  href="eventview1.php"><i class="material-icons"style="font-size:30px;color:white;">visibility</i>VIEW EVENT REGISTRATIONS</a>
                    </li>
                    <li>
                        <a  href="gview.php"><i class="material-icons"style="font-size:30px;color:white;">visibility</i>GROUP EVENT REGISTRATIONS</a>
                    </li>
                    <li>
                        <a  href="resultview.php"><i class="material-icons"style="font-size:30px;color:white;">visibility</i>VIEW RESULT</a>
                    </li>
                    <li>
                        <a  href="point.php"><i class="material-icons"style="font-size:30px;color:white;">visibility</i>VIEW MARKS</a>
                    </li>
                </ul>
               
            </div>
             </nav>  
        
        <hr>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
<body>
        <a href="staffentr.php">Back To Staff</a>
         <div class="a"><br> 
    <ul>
   
     
    <h2 align="center"><br><br> SCHEDULE ITEMS</h2>
    
    <form method="POST" action="sch_action.php">
            <P>SELECT ITEM</P>
            <?php
                    $qu="select * from tbl_event";
                    $s=mysqli_query($conn,$qu);
                    ?>
      <select   name="list" id="type" required>
      <option value=""disabled selected>Enter The event</option>
      <?php
while($d=mysqli_fetch_array($s))
{
    ?>
      <option value="<?php echo $d['event']; ?>"><?php echo $d['event']; ?></option>
      <?php } ?>
        </select><br>
            
    
<p>STAGE NUMBER</p>
 <select name="stage">
                <option> </option>
            <option>stage one</option>
            <option>stage two</option>
            <option>stage three </option>
            <option>stage four </option>
            <option>stage five</option>
 </select>
<br>  <br>              
                    <div class="input-box">
                    <span class="lnr lnr-calendar-full"></span>
                    <input type="date" name="date1" id="dob" class="input-box" min="<?= date('Y-m-d'); ?>" title="Date of birth" placeholder="Enter the Date of Birth"required >        </div>
                    <span id="demo" style="color:black;"></span>
                    <script>
                        function myFunction() 
                    {
                        var x = document.getElementById("dob").max;
                        document.getElementById("demo").innerHTML = "Invalid Date!!";
                    }
                    
</script>
                 
<p>TIME</p>
<time><input type="time" name="time"  placeholder="Demo time" step="900" onfocus="this.type='time'" value=""><br><br></time>
<input type='submit'  class="btn"name='submit' value='Submit' /><br><br>

    </form> 
    
    </div>  
    
    </ul>
   
</body>
</html>

