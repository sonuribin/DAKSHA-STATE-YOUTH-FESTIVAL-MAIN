<?php
	$eid=$_GET['eid'];
	include('conn.php');
	mysqli_query($conn,"delete from `tbl_reg` where eid='$eid'");
	header('location:eventview5.php');
?>