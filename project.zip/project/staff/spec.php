<?php
include('conn.php');
$country = $_POST['country'];
$sql = "select * from tbl_reg r,tb_users u,tbl_district d where r.uid=u.uid and '$country' in (r.a,r.b,r.c) and d.di_id=u.district";
$query = mysqli_query($conn,$sql);
echo 'No Registration Yet!';
$i=1;
while ($res = mysqli_fetch_array($query)) {
    echo '<tr><th height="50px">'.$i++ .'</th>
    <th>'.$res['fname'].'</th>
    <th>'.$res['district'].'</th>
    <th><input type="number" name="mark[]" class="input-box" min="0" max="50" value="" border="" /></th>
    <input type="hidden" name="uid[]" class="input-box" value='.$res['uid'].' border="" /></tr>';
}
