 <?php
$errors=array();
error_reporting(0);
  $db=mysqli_connect('localhost','root','','klp');
 if($db){
        echo 'success';
    }else{
        echo 'Error'.$db->error;
    }

if(isset($_POST['submit'])){       
$fname =$_POST['fname'];
$lname=$_POST['lname'];
$phno=$_POST['phno'];
$email=$_POST['email'];
$exp=$_POST['exp'];
$event_a=$_POST['event_a'];
$event_b=$_POST['event_b'];
$event_c=$_POST['event_c'];

                
                 //  $son="SELECT '$event_a',COUNT('$event_a') FROM tbl_judge;";

                    $li="select * from tbl_judge where event_a='$event_a'";
                    $mm=mysqli_query($db,$li);
                    $tt=mysqli_num_rows($mm);

                    $lt="select * from tbl_judge where event_b='$event_b'";
                    $mn=mysqli_query($db,$lt);
                    $vt=mysqli_num_rows($mn);

                    $lu="select * from tbl_judge where event_c='$event_c'";
                    $yy=mysqli_query($db,$lu);
                    $ut=mysqli_num_rows($yy);


                    if($tt==3 || $vt==3 || $ut==3){
                        echo "<script>alert('limit full');</script>";
                    }

                    else{

$sql="INSERT INTO tbl_judge(`fname`,`lname`,`phno`,`email`,`exp`,`event_a`,`event_b`,`event_c`) VALUES  ('$fname','$lname','$phno','$email','$exp','$event_a','$event_b','$event_c')";

 if(mysqli_query($db,$sql)){
    header("Location:judge.php");
}
else{
    echo("Sql===".$sql."Error ===".mysqli_error($db));
}
}
}
?>

