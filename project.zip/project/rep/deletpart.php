
<?php
	$uid=$_GET['uid'];
	include('conn.php');
	$sql1 = "select status from tbl_login where login_id=$uid";
		$qry =mysqli_query($conn,$sql1);
		$row1=mysqli_fetch_assoc($qry);
		$status=$row1['status'];
		if($status==0){
					 $sql = "UPDATE tbl_login SET status = 1 where login_id=$uid";
		   
		 $qry =mysqli_query($conn,$sql);
		 echo "<script> alert('User Blocked');</script>";
		 header('location:stview.php');
		} elseif ($status==1) {
          $sql = "UPDATE tbl_login SET status = 0 where login_id=$uid";
		   
		 $qry =mysqli_query($conn,$sql);
		 echo "<script> alert('User Unblocked');</script>";
			header('location:stview.php');		
		}
		else{
			echo "<script> alert('status is not set');</script>";
			header('location:stview.php');
		}
	
?>
