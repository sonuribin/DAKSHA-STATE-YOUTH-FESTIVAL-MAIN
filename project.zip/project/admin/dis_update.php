<?php
    include 'conn.php';
session_start();
$b=$_GET['id'];
$result=mysqli_query($conn,"SELECT * FROM `tbl_district` where `di_id`='$b'");
  $row=mysqli_fetch_array($result);

  
    ?> 
<!DOCTYPE html>  
<html>  
<head>  
<meta name="viewport" content="width=device-width, initial-scale=1">  
<style>  
body{  
  font-family: Calibri, Helvetica, sans-serif;  
  background-color: black;  
}  
.container {  
    padding: 50px;  
  background-color: white;  
}  
  
input[type=text], input[type=phone], textarea {  
  width: 100%;  
  padding: 15px;  
  margin: 5px 0 22px 0;  
  display: inline-block;  
  border: none;  
  background: #f1f1f1;  
}  
input[type=text]:focus, input[type=phone]:focus {  
  background-color: orange;  
  outline: none;  
}  
 div {  
            padding: 10px 0;  
         }  
hr {  
  border: 1px solid #f1f1f1;  
  margin-bottom: 25px;  
}  
.registerbtn {  
  background-color: #4CAF50;  
  color: white;  
  padding: 16px 20px;  
  margin: 8px 0;  
  border: none;  
  cursor: pointer;  
  width: 100%;  
  opacity: 0.9;  
}  
.registerbtn:hover {  
  opacity: 1;  
}  
</style> 
<style> form{
  padding: 150px 170px;
}</style> 
</head>  
<body> 
<form class="form" enctype="multipart/form-data" method="post" id="staff">
<div class="container bootstrap snippet">
    <div class="row">
      
      <div class="col-sm-2"></div>
    </div>

      <div class="col-sm-9">
            
              
          <div class="tab-content">
            <div class="tab-pane active" id="home">
                
                  
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="district"><h4>DISTRICT</h4></label>
                              <input name="district" type="text" class="form-control"  value ="<?php echo $row['district'];?>" id="district"  onchange="Validate();"  required>

                        
                          </div>
                      </div>
                          
                       
                  
                     
                      <div class="form-group">
                           <div class="col-xs-12">
                                <br>
                                <input type="hidden" name="hid" value="<?php echo $b;?>"/>
                                <input type="submit"  class="btn btn-lg btn-success"  name="save" value="Update">
                                
                <a class="btn btn-lg btn-danger" href="districtadd.php"><i class="glyphicon glyphicon-remove"></i> Cancel</a>
                            </div>
                      </div>
                </form>
              
              
              
             </div>

        </div><!--/col-9-->
    </div><!--/row-->
                                                      
        <img src="images/image-2.png" alt="" class="image-2">
      </div>
    </div>
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/main.js"></script>
    

  </body>  
</html>

<?php


if(isset($_POST['save']))
{

    $district=$_POST['district'];
    $aa = "UPDATE `tbl_district` SET `district`='$district' WHERE di_id='$b'";
    $saa = mysqli_query($conn,$aa);
echo "<script>window.location='districtadd.php'</script>";
   
}
?>