<?php
;
?>
<head>
<style>
body
{
background-image: url("dancer-2349565.png");
text-shadow: hsla(hue, saturation, lightness, alpha);	
}
form
{
text-shadow: hsla(hue, saturation, lightness, alpha);
background-color:silver;
letter-spacing: 0pt;
width:500px;
height: 400px;
border:10px ;
padding:40 px;
margin-top:150px;
margin-left: 700px;
text-align: center;
}

.button
{
	width: 30%;
	background:#ff6666 ;
	border: 1px solid;
	margin: 35px 0 10px;
	height: 32px;
	border-radius: 20px;
	padding: 0 10px;
	box-sizing: border-box;
	outline: none;
	color: #fff;
	cursor: pointer;
}
span{
font-size: 16px;
margin-left: 10px;
font family: sans-serif;
}

.input-box
{
width: 90%;
height: 35px;

	
	
	border-radius: 00px;
	padding: 0 10px;


}

</style>
<script type="text/javascript">
  window.history.forward();
  function noBack() {
      window.history.forward();
  }
</script>

</head>
<body>
	<a href="index.php">HOME</a>
<center>
 <form class="form" action="codes/login_action.php" method="post">
				
	

	<div id="validation-message" style="color:red;text-align:center;">
	
		<?php if(isset($_GET['error']))
			echo $_GET['error'];
		?><hr>
	</div>
	<br><br><br>
	<p><strong>LOGIN</strong></p>
	
	<div class="input-box" data-validate="Enter username or email">
		<input name="email" type="email" class="input-box" id="email" onchange="return Validata();" placeholder="Enter username or email" required>
					<span class="focus-input100"></span>
	</div>
<span id="msg5" style="color:red;"></span>
<script>		
function Validata() 
{
    var val = document.getElementById('email').value;

    if (!val.match(/([A-z0-9_\-\.]){1,}\@([A-z0-9_\-\.]){1,}\.([A-Za-z]){2,4}$/)) 
    {
        document.getElementById('msg5').innerHTML="Enter a Valid Email";
		
		     document.getElementById('email').value = "";
        return false;
    }
document.getElementById('msg5').innerHTML=" ";
    return true;
}

		</script>

				<br><br><div class="input-box" data-validate = "Enter password">
					<input name="password" type="password" id="pass" class="input-box" placeholder="Enter The Password" required>
					<span class="focus-input100"></span>
				</div>
				
				<div class="btn">
					<button type="submit" id="login" class="button">
						SUBMIT
					</button>
					<button type="reset" class="button">
						RESET
					</button>
				</div>

				
<br>
				<div class="text-center"><span>Don't have an account??</span>
					<a href="reg.php" class="txt2 hov1">
						<font color="#B12687">Register Here...</font>
					</a>
				</div>
  </form>

			
		</div>
	</div>
		<?php
if (@$_GET['registered'] == 'true')
   echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('You are Succesfully Registered')</script>");
?>
</center>

<?php
;
?>
</body>