<?php
	$id=$_GET['id'];
	$r_id=$_GET['r_id'];
	include('conn.php');
	$sql1 = "select status from tbl_login where login_id=$id";
		$qry =mysqli_query($conn,$sql1);
		$row1=mysqli_fetch_assoc($qry);
		$status=$row1['status'];
		if($status==0){
					 $sql = "UPDATE tbl_login SET status = 1 where login_id=$id";
		   
		 $qry =mysqli_query($conn,$sql);
		 echo "<script> alert('User Blocked');</script>";
		 header('location:repview.php');
		} elseif ($status==1) {
          $sql = "UPDATE tbl_login SET status = 0 where login_id=$id";
		   
		 $qry =mysqli_query($conn,$sql);
		 echo "<script> alert('User Unblocked');</script>";
			header('location:repview.php');		
		}
		else{
			echo "<script> alert('status is not set');</script>";
			header('location:repview.php');
		}
	
?>
