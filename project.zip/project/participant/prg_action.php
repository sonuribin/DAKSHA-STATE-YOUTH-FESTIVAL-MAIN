 <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klp";
$conn = new mysqli($servername,$username, $password,$dbname);
    
    if(isset($_POST['submit'])){
           
$name=$_POST['uid'];
$a=$_POST['a'];
$b=$_POST['b'];
$c=$_POST['c'];
 
 
 

$query = "SELECT * FROM tbl_reg WHERE uid='$name' ";
$userId = mysqli_query($conn, $query);
if(mysqli_num_rows($userId) < 1){
$sql=("INSERT INTO tbl_reg(`uid`, `a`, `b`, `c`) VALUES  ('$name','$a','$b','$c')");
if(mysqli_query($conn, $sql)) 
{

      
        echo "<script>
        alert('Type added succesfully');
      </script>";

 
      header('location:prgmreg.php');
    }

   
  }
  else{
    ?>
      <script>alert('event limit reached');
        window.location.href="prgmreg.php"
        </script>
<?php
}

}

mysqli_close($conn);
?>

