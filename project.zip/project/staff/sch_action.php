<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klp";
$conn = new mysqli($servername,$username, $password,$dbname);
    
if(isset($_POST['submit'])){
$list=$_POST['list'];
$stage=$_POST['stage'];
$date1=$_POST['date1'];
$time=$_POST['time'];

$query = "SELECT * FROM tbl_sch WHERE list='$list' ";
$userId = mysqli_query($conn, $query);
if(mysqli_num_rows($userId) < 1){

        $sql= "INSERT INTO tbl_sch (list,stage,date1,time) VALUES ('$list','$stage','$date1','$time')";
        if(mysqli_query($conn,$sql))
        {

             echo "<script>
        alert('Type added succesfully');
      </script>";
    header('Location:schedule.php');

}
}
 else{
    ?>
    <script type>
        alert("already schedulded");
        window.location.href="schedule.php";

    </script>
    
<?php
}
}

?>