
<html>
<head>
<style>
    .header img {
  float: left;
  width: 150px;
  height: 150px;
  background: #555;
}

.header h1 {
  position: relative;
  top: 10px;
  left: 10px;
}
.header h2 {
  position: relative;
  top: -30px;
  left: 10px;
}
#slider {
  position: relative;
  width: 500px;
  height: 350px;
  left: 1000;
  bottom: 10;
 
  overflow: hidden;
  box-shadow: 0 0 30px rgba(0, 0, 0, 0.3);
}
#slider ul {
  position: relative;
  list-style: none;
  height: 100%;
  width: 10000%;
  padding: 0;
  margin: 0;
  transition: all 750ms ease;
  left: 0;
}
#slider ul li {
  position: relative;
  height: 100%;
 
  float: left;
}
#slider ul li img{
  width: 300px;
  height: 350px;
}
 
#slider #prev, #slider #next {
  width: 50px;
  line-height: 50px;
  border-radius: 50%;
  font-size: 2rem;
  text-shadow: 0 0 20px rgba(0, 0, 0, 0.6);
  text-align: center;
  color: white;
  text-decoration: none;
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  transition: all 150ms ease;
}
#slider #prev:hover, #slider #next:hover {
  background-color: rgba(0, 0, 0, 0.5);
  text-shadow: 0;
}
#slider #prev {
  left: 10px;
}
#slider #next {
  right: 10px;
}

</style>
<script type="text/javascript">
  window.history.forward();
  function noBack() {
      window.history.forward();
  }
</script>
</head>
<body>
    <link rel="stylesheet" type="text/css" href="home2.css">
  
    
    <div class="header">
  <img align="center" src="logo1.jpg" alt="logo">
  <h1 style="color:darkblue; font-size: xx-large;">KERALA STATE YOUTH FESTIVAL</h1><br>
  <h2 style="color:black; font-size: large;">(Conduct by:KERALA STATE EDUCATION DEPARTMENT,Since 1956)</h2>
</div><br>

        
    

    <form>
        
    </form>
    <ul>
       
        <li><a href="reg.php">REGISTRATION</a>
            
        </li>
        <li><a href="plogin.php">LOGIN</a>
             
        </li> 
         <li><a>EVENT DETAILS</a>
        <ul>
            <li><a href="details.php">EVENT DETAILS</a></li>
            <li><a href="scview.php"> SCHEDULE</a></li>
        </ul>
        </li>
        <li><a href="resultview.php">RESULT</a></li>
           
       
        <li><a href="det.php"> ABOUT US</a>
            </li>
            </ul>
        </li>
        
        
      
         
    
    </ul>
    <br><br><br><br><br><br><br><br>
     <div id="slider" >
    <ul id="slideWrap"> 
      <li><img src="img3.jpg" alt=""></li>
      <li><img src="img4.jpg" alt=""></li>
      <li><img src="img5.jpg" alt=""></li>
    </ul>
    <a id="prev" href="#">&#8810;</a>
    <a id="next" href="#">&#8811;</a>
  </div>


  <script>
    var responsiveSlider = function() {

var slider = document.getElementById("slider");
var sliderWidth = slider.offsetWidth;
var slideList = document.getElementById("slideWrap");
var count = 1;
var items = slideList.querySelectorAll("li").length;
var prev = document.getElementById("prev");
var next = document.getElementById("next");

window.addEventListener('resize', function() {
  sliderWidth = slider.offsetWidth;
});

var prevSlide = function() {
  if(count > 1) {
    count = count - 2;
    slideList.style.left = "-" + count * sliderWidth + "px";
    count++;
  }
  else if(count = 1) {
    count = items - 1;
    slideList.style.left = "-" + count * sliderWidth + "px";
    count++;
  }
};

var nextSlide = function() {
  if(count < items) {
    slideList.style.left = "-" + count * sliderWidth + "px";
    count++;
  }
  else if(count = items) {
    slideList.style.left = "0px";
    count = 1;
  }
};

next.addEventListener("click", function() {
  nextSlide();
});

prev.addEventListener("click", function() {
  prevSlide();
});

setInterval(function() {
  nextSlide()
}, 5000);

};

window.onload = function() {
responsiveSlider();  
}
    
</script>
</body>    
</html>
