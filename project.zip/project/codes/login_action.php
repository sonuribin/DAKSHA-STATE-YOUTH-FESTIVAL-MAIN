<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klp";
$conn = new mysqli($servername, $username, $password,$dbname);
$email=$_POST['email'];
$password=$_POST['password'];
$query = "SELECT * FROM `tbl_login` WHERE email='$email'and password='$password'";
 $result = mysqli_query($conn,$query) or die(mysqli_error($conn));
 $value=mysqli_fetch_array($result);
 if(mysqli_num_rows($result) > 0)
 { 
      if ($value['utype_id'] == 1) {
            $_SESSION['admin'] = $value['login_id'];
            header('Location:../admin/adminp.php');
      } else if ($value['utype_id'] == 2 && $value['status'] == 0) {
            $_SESSION['rep'] = $value['login_id'];
            header('Location:../rep/repenter.php');
      } else if ($value['utype_id'] == 3 && $value['status'] ==0) {
            $_SESSION['users'] = $value['login_id'];
            header('Location:../participant/partentr.php');
      }else if ($value['utype_id'] == 4 && $value['status'] == 0 ) {
            $_SESSION['staff'] = $value['login_id'];
            header('Location:../staff/staffentr.php');
      }else {
        ?>
    <script>
        alert("invalid user");
        window.location.href="../plogin.php";
    </script>
    <?php
            
      }
 }
 else
 {
      ?>
    <script>
        alert("invalid user");
       window.location.href="../plogin.php";
    </script>
    <?php


 }
 mysqli_close($conn);