<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klp";
$conn = new mysqli($servername,$username, $password,$dbname);

if(isset($_POST['submit'])){
$district =$_POST['district'];

$query = "SELECT * FROM tbl_district WHERE district='$district' ";
$userId = mysqli_query($conn, $query);
if(mysqli_num_rows($userId) < 1){
    
   
  $details= "INSERT into tbl_district (district)values('$district')";
  if(mysqli_query($conn, $details)) 
  {

      
        echo "<script>
        alert('Type added succesfully');
      </script>";

 
      header('location:districtadd.php');
    }

   
  }
  else{
      echo "<script>alert('district already exist');</script>";
}
}



mysqli_close($conn);
?>
  
