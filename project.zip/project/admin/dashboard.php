<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin</title>
  <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
   <script type="text/javascript">
  window.history.forward();
  function noBack() {
      window.history.forward();
  }
</script>
</head>
<style>

<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">admin</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;">  
<a href="../plogin.php" class="btn btn-danger square-btn-adjust">Logout</a> </div>
        </nav>   
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
        <li class="text-center">
                    <img src="assets/img/find_user.png" class="user-image img-responsive"/>
          </li>
                    <li>

                       
                      
                        
                    <li>
                        <a  href="rep_reg.php"><i class="material-icons"style="font-size:30px;color:red;">person</i> ADD A REPRESENTATIVE</a>
                    </li>
                     <li>
                        <a  href="judge.php"><i class="material-icons"style="font-size:30px;color:red;">person</i> ADD A JUDGE</a>
                    </li>
               <li  >
                        <a  href="eventview.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i> VIEW PROGRAM REGISTRATIONS</a>
                    </li> 
                      <li  >
                        <a  href="groupview.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i> VIEW GROUP EVENT REGISTRATION</a>
                    </li>
                    <li  >
                        <a  href="scheview.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i> VIEW SCHEDULE</a>
                    </li> 
                    <li>
                     <a  href="histsche.php"><i class="material-icons"style="font-size:30px;color:red;">edit</i> SCHEDULE HISTORY</a>
                    </li>   
          <li >
                        <a  href="result2.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i> VIEW RESULT</a>
                    </li> -->
                    <li>
                        <a href="stview.php"><i class="material-icons"style="font-size:30px;color:red;">edit</i>VIEW/REMOVE STAFF</a>
                    </li>
                        <li>
                             <a  href="repview.php"><i class="material-icons"style="font-size:30px;color:red;">edit</i> VIEW/REMOVE REPRESENTATIVE</a>
                       </li>
                        <li  >
                             <a  href="districtadd.php"><i class="material-icons"style="font-size:30px;color:red;">edit</i> ADD A DISTRICT</a>
                    </li>
                    <li>
                     <a  href="eventadd.php"><i class="material-icons"style="font-size:30px;color:red;">edit</i> ADD AN EVENT</a>
                    </li>
                    <li>
                     <a  href="groupeventadd.php"><i class="material-icons"style="font-size:30px;color:red;">edit</i> ADD A GROUP EVENT</a>
                    </li>
            </div>
        }
</style>
</head>

<body style="color:black;" >

  <?php
  include 'conn.php';
    include 'session.php';
    if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
    ?>

<div id="header">
<?php include 'header.php';
?>
</div>
<div id="sidebar">
<?php
$active="dashboard";
include 'sidebar.php'; ?>

</div>
<div id="content">

  <div class="content-wrapper">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12 lg-12 sm-12">
          <h1 class="page-title">Dashboard</h1>
        </div>
      </div>
      <hr>
      <div class="row">
        <div class="col-md-12">
          <div class="row">
            <div class="col-md-3">
              <div class="panel panel-default panel-info" style="border-radius:50px;">
                <div class="panel-body panel-info bk-primary text-light" style="background-color:#D6EAF8; border-radius:50px">
                  <div class="stat-panel text-center">
                    <?php
                      $sql =" SELECT * from donor_personaldet ";
                      $result=mysqli_query($conn,$sql) or die("query failed.");
                      $row=mysqli_num_rows($result);

                    ?>


                    <div class="stat-panel-number h1"><?php echo $row?></div>
                    <div class="stat-panel-title text-uppercase"> Donors Available </div>
                    <br>
                      <button class="btn btn-danger" onclick="window.location.href = 'donor_list.php';">
                        Full Detail <i class="fa fa-arrow-right"></i>
                      </button>


                  </div>
                </div>

              </div>
            </div>
            <div class="col-md-3">
              <div class="panel panel-default panel-info" style="border-radius:50px;">
                <div class="panel-body panel-info bk-primary text-light" style="background-color:#D6EAF8; border-radius:50px">
                  <div class="stat-panel text-center">
                    <?php
                      $sql =" SELECT * from donor_personaldet ";
                      $result=mysqli_query($conn,$sql) or die("query failed.");
                      $row=mysqli_num_rows($result);

                    ?>


                    <div class="stat-panel-number h1"><?php echo $row?></div>
                    <div class="stat-panel-title text-uppercase"> Query Available </div>
                    <br>
                      <button class="btn btn-danger" onclick="window.location.href = 'query.php';">
                        Full Detail <i class="fa fa-arrow-right"></i>
                      </button>
                      


                  </div>
                  
                </div>
                

              </div>
            </div>
            <div class="col-md-3">
              <div class="panel panel-default panel-info" style="border-radius:50px;">
                <div class="panel-body panel-info bk-primary text-light" style="background-color:#E8DAEF ;border-radius:50px; ">
                  <div class="stat-panel text-center">
                    <?php
                      $sql2 ="SELECT * from contact_query where query_status=2 ";
                      $result2=mysqli_query($conn,$sql2) or die("query failed.");
                      $row2=mysqli_num_rows($result2);

                    ?>


                    <div class="stat-panel-number h1 "><?php echo "2" ?></div>
                    <div class="stat-panel-title text-uppercase"> Reports </div>
                    <br>
                    <button class="btn btn-danger" onclick="window.location.href = 'reports.php';">
                      Full Detail <i class="fa fa-arrow-right"></i>
                    </button>
                  </div>
                </div>

              </div>
            </div>

           

            

              </div>
            </div>



        </div>
      </div>
    </div>
  <?php
 } else {
     echo '<div class="alert alert-danger"><b> Please Login First To Access Admin Portal.</b></div>';
     ?>
     <form method="post" name="" action="login.php" class="form-horizontal">
       <div class="form-group">
         <div class="col-sm-8 col-sm-offset-4" style="float:left">

           <button class="btn btn-primary" name="submit" type="submit">Go to Login Page</button>
         </div>
       </div>
     </form>
 <?php }
  ?>

</body>
</html>
