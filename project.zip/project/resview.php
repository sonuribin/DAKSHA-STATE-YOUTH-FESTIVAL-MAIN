                        <?php
                        include "conn.php";
                        $query = ("SELECT tbl_point.event,tbl_point.mark,tbl_point.uid,tb_users.fname,tb_users.uid,tb_users.district,tbl_district.district from tbl_point,tb_users,tbl_district WHERE (tb_users.uid=tbl_point.uid) AND (tbl_point.event='$_POST[country]') AND (tb_users.district=tbl_district.di_id) ORDER BY tbl_point.mark DESC limit 2");
$results = mysqli_query($conn, $query);
$ii=1;
while($row=mysqli_fetch_array($results))
                    
                                    {                                      
                    
echo'<tr height="50px" style="color:black;" align="center"><td width="3%">'.$ii. ' PRIZE' .'</td><td width="8%"> '.$row['fname'].'</td><td width="8%">'.$row['district'] .'</td></tr>';
                              
$ii+=1;
}
?>
