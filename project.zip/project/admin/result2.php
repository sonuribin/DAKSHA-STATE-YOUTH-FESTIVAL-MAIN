<?php
include "conn.php";
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <link rel="stylesheet" href="style2.css">
<style>
body

</style>
</head>
<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin</title>
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">ADMIN</a> 
            </div>

        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                <li class="text-center">
                    <img src="assets/img/find_user.png" class="user-image img-responsive"/>
                    </li>
                
                    
               <li>
                       
                      <li>
                        <a  href="staff_reg.php"><i class="material-icons"style="font-size:30px;color:red;">supervisor_account</i> ADD A STAFF</a>
                    </li>
                    <li>
                        <a  href="rep_reg.php"><i class="material-icons"style="font-size:30px;color:red;">person</i> ADD A REPRESENTATIVE</a>
                    </li>
                    <li>
                        <a  href="judge.php"><i class="material-icons"style="font-size:30px;color:red;">person</i> ADD A JUDGE</a>
                    </li>
                           <li  >
                        <a  href="eventview.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i> VIEW PROGRAM REGISTRATIONS</a>
                    </li>   
                      <li  >
                        <a  href="groupview.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i> VIEW GROUP EVENT REGISTRATION</a>
                    </li>
                   <li  >
                        <a  href="scheview.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i> UPCOMING EVENTS</a>
                    </li>
                    <li>
                     <a  href="histsche.php"><i class="material-icons"style="font-size:30px;color:red;">edit</i> SCHEDULE HISTORY</a>
                    </li>                 
                    <li  >
                        <a  href="result2.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i> VIEW RESULT</a>
                    </li> -->
                    <li>
                        <a href="stview.php"><i class="material-icons"style="font-size:30px;color:red;">edit</i>VIEW/REMOVE STAFF</a>
                    </li>
                        <li>
                             <a  href="repview.php"><i class="material-icons"style="font-size:30px;color:red;">edit</i> VIEW/REMOVE REPRESENTATIVE</a>
                       </li>
                        <li  >
                             <a  href="districtadd.php"><i class="material-icons"style="font-size:30px;color:red;">edit</i> ADD A DISTRICT</a>
                    </li>
                     <li>
                     <a  href="eventadd.php"><i class="material-icons"style="font-size:30px;color:red;">edit</i> ADD AN EVENT</a>
                    </li>
                     <li>
                     <a  href="groupeventadd.php"><i class="material-icons"style="font-size:30px;color:red;">edit</i> ADD A GROUP EVENT</a>
                    </li>
               
            </div>
            
        </nav>  
        
        <hr>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     
                     <body>
                        <body>
    <a href="adminp.php">Back to Admin</a>

<ul>   
        <div class="a"><br>
<h2 align="center"><u>RESULTS</u></h2>
             <form method="POST" action="">
            <P>Event</P>
            <select name="list" id="type" onchange="change();" required>
                        <option value=""disabled selected>select the program</option>
        <?php
        $i=0;
            $sel=mysqli_query($conn,"select * from  tbl_event");
             while($r=mysqli_fetch_array($sel))
            {
            ?>
           <option value="<?php echo $r['event'];?>"><?php echo $r['event'];?></option>
            <?php
        }
        ?>
        </select>

    
<div class="">
    <center>
        <table width="100%" border="0" class="table table-bordered">
            <tr>
                <table border=5 bordercolor=black>
                    <thead style="color:red">
                         <th height="50px" width="3%"></th>
                        <th height="50px" width="8%">NAME</th>
                        <th height="50px" width="8%">DISTRICT</th>

                            
             </thead>
        <tbody id="event">
        </tbody>
            </select>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
      <script>
                                            function change() {
                                                var country = $("#type").val();

                                                $.ajax({
                                                    type: "POST",
                                                    url: "resview2.php",
                                                    data: "country=" + country,
                                                    cache: false,
                                                    success: function(response) {
                                                        //alert(response);return false;
                                                        $("#event").html(response);
                                                    }
                                                });

                                            }
                                  </script>   

    </form> 
        </a>
    </div>  
    
    </ul>   
</body>
</html>
<?php
;
?>